import logging
import random
import string
import sqlite3
from telegram import Update
from telegram.ext import Application, MessageHandler, filters, ContextTypes

BOT_TOKEN = "GANTI_TOKEN_BOT_KAMU"

OWNER_IDS = [8695568315]
ADMIN_IDS = [8695568315]

TAX_PERCENT = 3

ROULETTE = [
    0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,
    8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,
    28,12,35,3,26
]

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

def db():
    return sqlite3.connect("reme_bot.db")

def init_db():
    conn = db()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        saldo INTEGER DEFAULT 0
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS rooms (
        room_id TEXT PRIMARY KEY,
        player1_id INTEGER,
        player2_id INTEGER,
        taruhan INTEGER,
        total_ronde INTEGER,
        ronde INTEGER DEFAULT 1,
        skor1 INTEGER DEFAULT 0,
        skor2 INTEGER DEFAULT 0,
        spin1 INTEGER DEFAULT -1,
        spin2 INTEGER DEFAULT -1,
        status TEXT DEFAULT 'waiting',
        chat_id INTEGER
    )
    """)

    conn.commit()
    conn.close()

def get_user(user_id, username="user"):
    conn = db()
    c = conn.cursor()

    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = c.fetchone()

    if not user:
        c.execute(
            "INSERT INTO users (user_id, username, saldo) VALUES (?, ?, ?)",
            (user_id, username, 0)
        )
        conn.commit()

    conn.close()

def get_saldo(user_id):
    conn = db()
    c = conn.cursor()

    c.execute("SELECT saldo FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone()

    conn.close()

    return row[0] if row else 0

def update_saldo(user_id, jumlah):
    conn = db()
    c = conn.cursor()

    c.execute(
        "UPDATE users SET saldo = saldo + ? WHERE user_id=?",
        (jumlah, user_id)
    )

    conn.commit()
    conn.close()

def set_saldo(user_id, jumlah):
    conn = db()
    c = conn.cursor()

    c.execute(
        "UPDATE users SET saldo=? WHERE user_id=?",
        (jumlah, user_id)
    )

    conn.commit()
    conn.close()

def get_room_by_player(user_id):
    conn = db()
    c = conn.cursor()

    c.execute("""
    SELECT * FROM rooms
    WHERE (player1_id=? OR player2_id=?)
    AND status IN ('waiting', 'playing')
    """, (user_id, user_id))

    room = c.fetchone()

    conn.close()

    return room

def get_room(room_id):
    conn = db()
    c = conn.cursor()

    c.execute("SELECT * FROM rooms WHERE room_id=?", (room_id,))
    room = c.fetchone()

    conn.close()

    return room

def update_room(room_id, **kwargs):
    conn = db()
    c = conn.cursor()

    for key, value in kwargs.items():
        c.execute(
            f"UPDATE rooms SET {key}=? WHERE room_id=?",
            (value, room_id)
        )

    conn.commit()
    conn.close()

def delete_room(room_id):
    conn = db()
    c = conn.cursor()

    c.execute("DELETE FROM rooms WHERE room_id=?", (room_id,))

    conn.commit()
    conn.close()

def generate_room_id():
    return ''.join(random.choices(
        string.ascii_lowercase + string.digits,
        k=10
    ))

def spin():
    return random.choice(ROULETTE)

def hitung_reme(angka):
    if angka <= 9:
        return angka

    total = sum(int(x) for x in str(angka))

    while total > 9:
        total = sum(int(x) for x in str(total))

    return total

async def handle_saldo(update, context):
    user = update.effective_user

    get_user(user.id, user.username or user.first_name)

    saldo = get_saldo(user.id)

    await update.message.reply_text(
        f"💰 Saldo kamu: Rp{saldo:,}"
    )

async def handle_addsaldo(update, context):
    user = update.effective_user

    if user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Admin only")
        return

    parts = update.message.text.split()

    if len(parts) != 3:
        await update.message.reply_text(
            "Format: .addsaldo user_id jumlah"
        )
        return

    try:
        target_id = int(parts[1])
        jumlah = int(parts[2])
    except:
        await update.message.reply_text("❌ Format salah")
        return

    get_user(target_id)

    update_saldo(target_id, jumlah)

    saldo = get_saldo(target_id)

    await update.message.reply_text(
        f"✅ Saldo berhasil ditambah\nSaldo sekarang: Rp{saldo:,}"
    )

async def handle_setsaldo(update, context):
    user = update.effective_user

    if user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Admin only")
        return

    parts = update.message.text.split()

    if len(parts) != 3:
        await update.message.reply_text(
            "Format: .setsaldo user_id jumlah"
        )
        return

    try:
        target_id = int(parts[1])
        jumlah = int(parts[2])
    except:
        await update.message.reply_text("❌ Format salah")
        return

    get_user(target_id)

    set_saldo(target_id, jumlah)

    await update.message.reply_text(
        f"✅ Saldo diset menjadi Rp{jumlah:,}"
    )

async def handle_reme(update, context):
    user = update.effective_user
    chat_id = update.effective_chat.id

    get_user(user.id, user.username or user.first_name)

    parts = update.message.text.split()

    if len(parts) != 3:
        await update.message.reply_text(
            "Format: .reme taruhan ronde\nContoh: .reme 5000 1r"
        )
        return

    try:
        taruhan = int(parts[1])
        ronde = int(parts[2].replace("r", ""))
    except:
        await update.message.reply_text("❌ Format salah")
        return

    if get_saldo(user.id) < taruhan:
        await update.message.reply_text("❌ Saldo tidak cukup")
        return

    if get_room_by_player(user.id):
        await update.message.reply_text("❌ Kamu masih di room")
        return

    conn = db()
    c = conn.cursor()

    c.execute("""
    SELECT * FROM rooms
    WHERE taruhan=?
    AND total_ronde=?
    AND status='waiting'
    AND player2_id IS NULL
    AND chat_id=?
    """, (taruhan, ronde, chat_id))

    waiting = c.fetchone()

    conn.close()

    if waiting:
        room_id = waiting[0]
        p1 = waiting[1]

        update_saldo(user.id, -taruhan)
        update_saldo(p1, -taruhan)

        update_room(
            room_id,
            player2_id=user.id,
            status="playing"
        )

        await update.message.reply_text(
            f"🎰 Match ditemukan!\nRoom: {room_id}\nKetik .spinr"
        )

    else:
        room_id = generate_room_id()

        conn = db()
        c = conn.cursor()

        c.execute("""
        INSERT INTO rooms (
            room_id,
            player1_id,
            taruhan,
            total_ronde,
            chat_id
        )
        VALUES (?, ?, ?, ?, ?)
        """, (
            room_id,
            user.id,
            taruhan,
            ronde,
            chat_id
        ))

        conn.commit()
        conn.close()

        await update.message.reply_text(
            f"🎰 Room dibuat\nID: {room_id}"
        )

async def handle_spinr(update, context):
    user = update.effective_user

    room = get_room_by_player(user.id)

    if not room:
        await update.message.reply_text(
            "❌ Kamu tidak ada room"
        )
        return

    (
        room_id,
        p1,
        p2,
        taruhan,
        total_ronde,
        ronde,
        skor1,
        skor2,
        spin1,
        spin2,
        status,
        chat_id
    ) = room

    if status != "playing":
        await update.message.reply_text(
            "❌ Room belum siap"
        )
        return

    angka = spin()
    reme = hitung_reme(angka)

    if user.id == p1:
        if spin1 != -1:
            await update.message.reply_text(
                "❌ Kamu sudah spin"
            )
            return

        update_room(room_id, spin1=angka)

    elif user.id == p2:
        if spin2 != -1:
            await update.message.reply_text(
                "❌ Kamu sudah spin"
            )
            return

        update_room(room_id, spin2=angka)

    await update.message.reply_text(
        f"🎰 {user.first_name} mendapatkan {angka} → REME {reme}"
    )

    room = get_room(room_id)

    spin1 = room[8]
    spin2 = room[9]

    if spin1 != -1 and spin2 != -1:
        r1 = hitung_reme(spin1)
        r2 = hitung_reme(spin2)

        if r1 > r2:
            skor1 += 1
        elif r2 > r1:
            skor2 += 1

        if ronde >= total_ronde:
            total_pot = taruhan * 2
            tax = int(total_pot * TAX_PERCENT / 100)
            hadiah = total_pot - tax

            if skor1 > skor2:
                update_saldo(p1, hadiah)
                winner = p1
            elif skor2 > skor1:
                update_saldo(p2, hadiah)
                winner = p2
            else:
                update_saldo(p1, taruhan)
                update_saldo(p2, taruhan)
                winner = "SERI"

            delete_room(room_id)

            await update.message.reply_text(
                f"🏆 Match selesai\nWinner: {winner}"
            )

        else:
            update_room(
                room_id,
                ronde=ronde + 1,
                skor1=skor1,
                skor2=skor2,
                spin1=-1,
                spin2=-1
            )

            await update.message.reply_text(
                f"📊 Score {skor1} - {skor2}\nLanjut ronde berikutnya"
            )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return

    text = update.message.text.lower()

    try:
        if text.startswith(".saldo"):
            await handle_saldo(update, context)

        elif text.startswith(".addsaldo"):
            await handle_addsaldo(update, context)

        elif text.startswith(".setsaldo"):
            await handle_setsaldo(update, context)

        elif text.startswith(".reme"):
            await handle_reme(update, context)

        elif text.startswith(".spinr"):
            await handle_spinr(update, context)

    except Exception as e:
        logging.error(e)

        await update.message.reply_text(
            f"❌ Error: {e}"
        )

def main():
    init_db()

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(
        MessageHandler(
            filters.TEXT,
            handle_message
        )
    )

    print("Bot running...")

    app.run_polling()

if __name__ == "__main__":
    main()
